# Spelling Builder: put it on phones (GitHub Pages)

This folder is the whole app. You host it for free on GitHub, then add it to each phone's home screen.

## 1. Put the files on GitHub
1. Sign in at github.com, tap **+**, then **New repository**.
2. Name it something like `spelling`. Choose **Public** (free GitHub Pages needs a public repository). Tap **Create repository**.
3. Tap **uploading an existing file** (or **Add file > Upload files**).
4. Upload ALL of these files: `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`, `apple-touch-icon.png`.
5. Tap **Commit changes**.

## 2. Turn on the website
1. In the repository, open **Settings > Pages**.
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
3. Choose branch **main** and folder **/ (root)**, then **Save**.
4. Wait a minute or two. The page shows your address, which looks like
   `https://YOUR-USERNAME.github.io/spelling/`

Nothing personal is in this public repository. His words, stars and beetles stay on the phones (or in the private repository in step 6).

## 3. Add it to an iPhone (do this on each phone, including his dad's)
1. Open the address in **Safari**.
2. Tap **Share**, then **Add to Home Screen**, then **Add**.
3. Open it from the home screen once while online. After that it also works without internet.

(Android: open it in Chrome, tap the menu, then **Install app** or **Add to Home screen**.)

## 4. Add all the weekly lists at once
Open **Grown-ups > Weekly lists**.
1. Choose the date the first list starts (the Monday).
2. Type one line per week, with the words separated by spaces or commas. Write `skip` on a line for a week with no new list (holidays).
3. Tap **Add these lists**.

The app switches to each week's list by itself on the Monday, at the hour you choose (default 12 o'clock, so the Monday morning check still uses last week's words). You can add more weeks any time, or delete a week. Lists are shared between phones if you turned on sharing.

## 5. Starting fresh
If you were only testing, open **Grown-ups** and use **Reset stars and beetles**, **Clear progress** and **Start a new week**. Sparkly, the rainbow stag beetle, always stays in his collection as beetle number 1.

## 6. Share progress between two phones (optional)
Each phone keeps its own copy of the progress. To keep two phones in step, they both read and write one small file in a PRIVATE GitHub repository that only you own. Do this once:

1. **Create the private repository.** On github.com tap **+ > New repository**. Name it `spelling-data`. Choose **Private**. Tick **Add a README file**. Tap **Create repository**.
2. **Create an access token.** Go to your profile picture > **Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token**.
   - Name: `spelling`. Expiration: the longest offered.
   - **Repository access**: *Only select repositories*, then choose `spelling-data`.
   - **Permissions > Repository permissions > Contents**: set to **Read and write**.
   - Tap **Generate token** and copy it (you only see it once).
3. **On each phone**, open the app > **Grown-ups > Share between phones**. Enter your GitHub username, `spelling-data`, and the token. Tap **Save and sync**. You can send the token to his dad in a private message.

After that the phones keep each other up to date: the app saves changes a few seconds after they happen and checks for the other phone's changes whenever it is opened. If both phones were used at the same time, nothing is lost: beetles and practice days are combined, and the larger star count is kept.

Good to know about sharing:
- The token is stored on each phone. If a phone is lost, delete the token on GitHub (Developer settings) and make a new one.
- When the token expires, make a new one and enter it again on both phones.
- The voice, colours and letter colour stay separate on each phone. The word lists, plan, stars, beetles and progress are shared.
- The shared file holds only his words, stars, beetles and spelling results.

## 7. Moving his progress by hand (no sharing)
In the old version open **Grown-ups > Back up and restore > Create backup > Copy**. In the new app paste it into **Restore from a backup** and tap **Restore**.

## 8. Updating the app later
1. In your `spelling` repository, upload the new `index.html` (Add file > Upload files, it replaces the old one).
2. Open `sw.js` and change `spelling-builder-v6` to `spelling-builder-v7` (then v4 and so on). This makes phones pick up the new version.
3. Open the app twice (the first time it fetches the update, the second time it shows it).

## Mixed quiz
Open **My week** (📅) and tap **Start a quiz**, or use **Grown-ups > Mixed quiz**. The quiz mixes words from all his lists so far, with no hints and every letter available. About 4 in 10 words are ones he finds hard. Set the number of words in Grown-ups.

## Beetle battles and fewer stars for words he knows well
- **Battle tickets:** finishing a round earns 2, a quiz or check earns 3. He can earn up to 5 a day and keep up to 10. One battle costs 1 ticket.
- **Battle:** he picks one of his beetles, a wild beetle appears, and over 3 rounds he picks a power (Size, Strength, Speed, Sparkle). The higher number wins the round. Size is the real length in mm. The other three are game scores out of 10 that I chose, so feel free to argue with them.
- **No more stars for easy words:** a word he has spelled right every time, more than 20 times in the last 3 months, stops earning stars (the Grown-ups menu lists these words). It still counts for practice days and beetle facts.

## Good to know
- The Grown-ups menu has no password. A screen lock on the phone is the simplest protection.
- Speech voices come from the phone. The app automatically picks the clearest one it finds (Samantha, Ava, Zoe or Oliver, in the Enhanced or Premium version). To get them on an iPhone: Settings > Accessibility > Spoken Content > Voices > English, choose the voice and tap the download arrow, then fully close and reopen the app. You can pick a different one under Grown-ups > Voice. Siri voices are usually not available to apps and websites.
- On iPhone the silent switch can mute the held sounds (ffff, mmmm), but the voice still speaks.
